#!/bin/bash

python3 -m venv venv
from src import constants

# INPUT_IMAGE_PATH = "../models/" + constants.PROJECT_NAME + "/" + constants.INPUT_IMAGE
INPUT_IMAGE_PATH = "../../" + constants.INPUT_IMAGE
